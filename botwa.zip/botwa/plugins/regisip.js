const fs = require('fs');
const { execSync } = require('child_process');
const setting = require('../setting.js');
const { isOwner } = require('../lib/helper');

if (!process.env.HOME) {
  process.env.HOME = '/root';
}

module.exports = {
  name: '.regisip',
  command: ['.regisip'],
  async execute(conn, sender, args, msg) {
    // ✅ FIX LID: ambil JID pengirim dengan benar (mendukung @lid dan @s.whatsapp.net)
    const userJid = msg.key.participant || msg.key.remoteJid;

    // ✅ FIX: gunakan helper isOwner yang mendukung LID
    if (!isOwner(userJid, setting.owner)) {
      return conn.sendMessage(sender, {
        text: '❌ Hanya *Owner* yang bisa menggunakan perintah ini.'
      }, { quoted: msg });
    }

    if (args.length < 3) {
      return conn.sendMessage(sender, {
        text: `❌ Contoh penggunaan:\n.regisip <ip> <nama> <masa aktif>\n\nContoh:\n.regisip 123.123.123.123 Andy 30`
      }, { quoted: msg });
    }

    const [ip, ...rest] = args;
    const name = rest.slice(0, -1).join(' ');
    const expInput = rest[rest.length - 1];
    const exp = parseInt(expInput);

    if (!ip || !name || isNaN(exp)) {
      return conn.sendMessage(sender, {
        text: '⚠️ Format salah. Pastikan IP, nama, dan masa aktif (angka hari) valid.'
      }, { quoted: msg });
    }

    const REPO = 'https://github.com/Andyyuda/izinbot.git';
    const EMAIL = 'andyyuda51@gmail.com';
    const USER = 'Andyyuda';
    const TOKEN = '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';

    try {
      execSync(`git clone ${REPO} /root/ipvps/`);
      const filePath = '/root/ipvps/ip';
      const existing = fs.existsSync(filePath) ? fs.readFileSync(filePath, 'utf8') : '';

      if (existing.includes(ip)) {
        return conn.sendMessage(sender, { text: '❌ IP sudah terdaftar.' }, { quoted: msg });
      }

      const expDate = new Date();
      expDate.setDate(expDate.getDate() + exp);
      const expString = expDate.toISOString().split('T')[0];

      fs.appendFileSync(filePath, `### ${name} ${expString} ${ip}\n`);

      execSync(`cd /root/ipvps && git config user.email "${EMAIL}"`);
      execSync(`cd /root/ipvps && git config user.name "${USER}"`);
      execSync(`cd /root/ipvps && rm -rf .git && git init && git add . && git commit -m "add ip" && git branch -M main`);
      execSync(`cd /root/ipvps && git remote add origin ${REPO}`);
      execSync(`cd /root/ipvps && git push -f https://${TOKEN}@github.com/Andyyuda/izinbot.git`);
      execSync('rm -rf /root/ipvps');

      conn.sendMessage(sender, {
        text: `✅ *Registrasi IP Berhasil!*\n\n🌐 IP: ${ip}\n👤 Nama: ${name}\n📅 Expired: ${expString}`
      }, { quoted: msg });
    } catch (err) {
      conn.sendMessage(sender, {
        text: `❌ Gagal push ke GitHub:\n${err.message}`
      }, { quoted: msg });
    }
  }
};
